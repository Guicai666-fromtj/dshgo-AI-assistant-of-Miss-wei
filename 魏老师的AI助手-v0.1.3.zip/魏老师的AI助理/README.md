# 魏老师的AI助理

给魏老师（天津市实验中学数学老师）用的 AI 助手。

> **跑在魏老师自己手机上的 dsh-go 里**，一个全新的 DSH 环境。别在这台机器上给她装东西、也别抄这台机器的路径和插件。

## 魏老师怎么开始（只发一个链接）

仓库：<https://github.com/Guicai666-fromtj/dshgo-AI-assistant-of-Miss-wei>

她打开 dsh-go，把链接粘进对话框发出去，剩下的由 agent 自己走完：clone → 装配人格 → 自检 → 建周结任务 → 装插件（她点「启用」）→ 装 DeepTutor + 本地模型 + 知识库 → 演示「B 站网课读成笔记并入库」→ 给她一页功能介绍。完整步骤见 `AGENTS.md` §0.6，给她的那一页是 `她怎么用.md`。

## 文件

- `AGENTS.md` —— 给 agent 看的手册：装配人格提示词、记忆系统、定时任务、装插件、装 DeepTutor、接本地模型、知识库嵌本地 embedding、把 B 站网课读成笔记入知识库、当管理层、帮老师打开 DeepTutor
- `人格提示词.md` —— 助理的人设 system prompt（语气、性格、怎么关心她、底线）
- `她怎么用.md` —— 给魏老师本人看的一页纸：三步上手 + 怎么开口 + 它记得什么、不干什么
- `mem/` —— 四柜记忆：看板 `index.md` / 事实 `facts.json` / 欠账 `threads.json` / 流水 `stream.jsonl` / 归档 `archive/` / 周报 `weekly/`
- `bin/mem.mjs`、`bin/memcore.mjs` —— 记忆系统命令（add/recall、看板/事实/欠账/归档/周报/体检）
- `插件目录.md` —— 给她那台 dsh-go 用的插件清单：哪些自带、哪些要开、怎么装、哪些别装
- `魏老师资料.md` —— 已并入记忆系统，现在只是路标

## 跑起来

没有独立程序入口：助理就是 dsh-go 里的 agent，靠本目录的 AGENTS.md + 人格提示词 + mem/ 记忆运行。把整个目录放进她手机 DSH 的工作区，在 dsh-go 里选这个目录开新会话即可。

## 上传到 GitHub / 从 GitHub 装

上传（鬼才这边，仓库地址换成你的）：

```bash
git remote add origin <仓库地址>
git push -u origin main
```

她手机上装（见 AGENTS.md §0.5）：

```bash
git clone <仓库地址> ~/workspace/魏老师的AI助理
```
